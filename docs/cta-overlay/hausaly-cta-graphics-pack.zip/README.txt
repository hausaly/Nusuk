HAUSALY UMRAH CTA - GRAPHICS PACK
=================================
Everything here is transparent and ready to drop into Premiere, After Effects, DaVinci Resolve, CapCut, Canva, Figma, Illustrator, etc.

FOLDERS
  png/   Transparent PNGs, exported at 2x (the video was designed at 1080x1920, so these are double size - scale to 50% to match the video exactly).
         00_full_scene_cards   each full scene exactly as in the video (sheet + all content) - easiest to use as a single layer
         01_paper_sheets       blank torn paper sheets (with the teal paper peeking out behind)
         02_offer_strips       torn teal/dark strips, blank and with the offer text
         03_tabs_and_labels    UMRAH PACKAGE / FLY FROM / EXCLUSIVE OFFERS tabs and the logo tab
         04_scene1_elements    14 DAYS, marker circle, 10 & 4 day notes, visa ticket sticker, MULTIPLE ENTRY VISA stamp
         05_scene2_elements    KANO / ABUJA / LAGOS tiles, flight line, Saudi logo, WHAT'S INCLUDED, six checklist rows
         06_scene4_elements    BOOK NOW, WhatsApp number card, 36 STATES, address note, trust logos, website pill
         07_transition_wipes   the teal wipe used between scenes (1560x1980, slide it across the frame)
  svg/   True vector versions (42 files) of the shapes, text (converted to outlines, so no fonts needed), icons, tapes, tabs, notes, cards,
         strips and the wipe. Open in Illustrator / Figma / Inkscape / Affinity to recolour or edit shapes.
         (The visa ticket photo, logos, Saudi logo, trust strip and Nigeria map are raster images, so they exist as PNG only.)
  fonts/ Anton (headlines) and Poppins (labels) - free Google fonts (SIL Open Font License) - install them if you want to retype any text.

BRAND COLOURS
  Teal #73d0cf   Deep teal #0d5557   Ink #161616   Cream paper #f3efe7   Note white #fffcf5   Dark strip #12292b

TIPS
  * Wrap anything in a slight drop shadow if your editor strips it; the PNGs already include soft shadows.
  * For motion like the video: slide cards up ~40px with fade (0.6s ease-out), wipe text left-to-right, stamp = scale 1.8 -> 1 in 0.3s.
